require('./controllers/settings');
module.exports.text = "➤ Server running on http://localhost:";
module.exports.text2 = " ✔";
module.exports.port = port;